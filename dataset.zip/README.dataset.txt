# mushroomDetection > 2024-01-04 2:32pm
https://universe.roboflow.com/yolo-m191n/mushroomdetection-buflq

Provided by a Roboflow user
License: CC BY 4.0

